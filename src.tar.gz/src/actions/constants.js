export const USER_LOGIN_REQUEST = 'auth/login/request';
export const USER_LOGIN_SUCCESS = 'auth/login/success';
export const USER_LOGIN_FAILED = 'auth/login/failed';

// polling
export const DATA_POLLING_REQUEST = 'data/polling/request';
export const DATA_POLLING_SUCCESS = 'data/polling/success';
export const DATA_POLLING_FAILED = 'data/polling/failed';
