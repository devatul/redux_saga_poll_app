import React from 'react';
import { Header } from '../../components/header/header';

export class App extends React.Component {
  render() {
    return (
      <Header />
    );
  }
}
