import React from 'react';

export class AdminPanel extends React.Component {

  render() {
    return (
      <div className="container">
        <center>
          <mark>
            <i>
              <h2 className="text-capitalize">
                {this.props.loginabc.data.data.username}
              </h2>
            </i>
          </mark>
        </center>
      </div>
    );
  }
}
