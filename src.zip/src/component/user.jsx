import React from 'react';

export class UserPanel extends React.Component {

  render() {
    return (
      <div className="container">
        <center>
          <mark>
            <i>
              <h1>
                user
              </h1>
            </i>
          </mark>
        </center>
      </div>
    );
  }
}
