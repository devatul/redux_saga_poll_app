import React from 'react';
import { Link } from 'react-router';

export class Dashboard extends React.Component {

  render() {
    let text = 'text-danger';
    let LoginInfo = 'Invalid Username or password';
    let PollingOptions = 'Go Back to try again';
    let UserRole = `userPanel/${this.props.loginabc.data.data.username}`;
    if (this.props.loginabc.data.data.role === 'admin') {
      UserRole = `adminPanel/${this.props.loginabc.data.data.username}`;
    }
    if (this.props.loginabc.data.data.username) {
      LoginInfo = `Welcome ${this.props.loginabc.data.data.username}`;
      text = 'text-success';
      PollingOptions = 'Go to polling Options';
    }
    return (
      <div className="container">
        <center>
          <mark>
            <i>
              <h1>
                <p className="text-capitalize">
                  <p className={text}>
                    {LoginInfo}
                  </p>
                </p>
              </h1>
            </i>
          </mark>
        </center>
        <Link to={UserRole}>
          <button className="btn pull-right">{PollingOptions}</button>
        </Link>
      </div>
    );
  }
}
