export const USER_LOGIN_REQUEST = 'auth/login/request';
export const USER_LOGIN_SUCCESS = 'auth/login/success';
export const USER_LOGIN_ERROR = 'auth/login/error';
