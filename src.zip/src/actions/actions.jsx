
export function login(username, password) {
  return { type: 'Login', username, password };
}

export function viewPollList() {
  return { type: 'ViewPolls' };
}
