import { call, put, takeLatest } from 'redux-saga/effects';
import axios from 'axios';

export function* createSagaAsync(action) {
  try {
    const response = yield call(axios.post, `http://144.76.34.244:3333/login?username=${action.username}&password=${action.password}`);
    yield put({ type: 'Login_Success', response });
    return response.data;
  } catch (e) {
    yield put({ type: 'Login_Error', e });
    return e;
  }
}

export function* createSagaPollingList(action) {
  try {
    console.log(action.type);
    const response = yield call(axios.post, 'http://144.76.34.244:3333/list_polls');
    console.log(response);
    yield put({ type: 'ViewPolls', response });
  } catch (e) {
    yield put({ type: 'ViewPollError', e });
  }
}

export function* watchCreateLesson() {
  yield takeLatest('Login', createSagaAsync);
  yield takeLatest('ViewPolls', createSagaPollingList);
}
export default function* rootSaga() {
  yield [
    watchCreateLesson(),
  ];
}
