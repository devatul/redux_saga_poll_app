import { Router, Route, IndexRoute } from 'react-router';
import ReactDOM from 'react-dom';
import React from 'react';
import { Provider } from 'react-redux';
import store, { history } from './Store/store';

import { LoginContainer } from './containers/login';
import { view } from './containers/main';
import { SignupContainer } from './containers/Signup';
import { DashboardContainer } from './containers/dashboard';
import { UserPanelContainer } from './containers/userPanel';
import { AdminPanelContainer } from './containers/adminPanel';

ReactDOM.render(
  <Provider store={store}>
    <Router history={history}>
      <Route path="/" component={view}>
        <IndexRoute component={LoginContainer} />
        <Route path="signup" component={SignupContainer} />
        <Route path="dashboard/:data" component={DashboardContainer} />
        <Route path="UserPanel/:id" component={UserPanelContainer} />
        <Route path="adminPanel/:id" component={AdminPanelContainer} />
      </Route>
    </Router>
  </Provider>
  , document.getElementById('app'));
