import React from 'react';

import { AdminPanel } from '../component/admin';

export class AdminPanelContainer extends React.Component {

  render() {
    return (
      <div>
        <AdminPanel {...this.props} />
      </div>
    );
  }
}
