import React from 'react';

import { UserPanel } from '../component/user';

export class UserPanelContainer extends React.Component {

  componentWillMount() {
    this.props.ViewPolls();
  }
  render() {
    return (
      <div>
        <UserPanel
          {...this.props}
        />
      </div>
    );
  }
}
