 const pollList = [];

 export default pollList;
