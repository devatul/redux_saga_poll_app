const user = {
  data: [],
  isLoading: false,
  isError: false,
  isSucess: false,
  errors: [],
};
export default user;
